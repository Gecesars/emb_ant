%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-11-12T07:24:38-03:00*%
%TF.ProjectId,2_elementos,325f656c-656d-4656-9e74-6f732e6b6963,R12 / arte HFSS M00*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-11-12 07:24:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,0.000000*%
G04 APERTURE END LIST*
D10*
G36*
X105000000Y-154000000D02*
G01*
X55000000Y-154000000D01*
X55000000Y-66000000D01*
X105000000Y-66000000D01*
X105000000Y-154000000D01*
G37*
M02*
