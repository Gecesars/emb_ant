%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-11-09T12:59:53-03:00*%
%TF.ProjectId,2_elementos,325f656c-656d-4656-9e74-6f732e6b6963,R01 / arte HFSS v05*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-11-09 12:59:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,0.000000*%
G04 APERTURE END LIST*
D10*
G36*
X108000000Y-148800000D02*
G01*
X59000000Y-148800000D01*
X59000000Y-66000000D01*
X108000000Y-66000000D01*
X108000000Y-148800000D01*
G37*
M02*
