%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-11-06T14:15:00-03:00*%
%TF.ProjectId,P1H_Individual,5031485f-496e-4646-9976-696475616c2e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-11-06 14:15:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,0.000000*%
G04 APERTURE END LIST*
D10*
G36*
X35906250Y-53906250D02*
G01*
X8093750Y-53906250D01*
X8093750Y-26093750D01*
X35906250Y-26093750D01*
X35906250Y-53906250D01*
G37*
M02*
